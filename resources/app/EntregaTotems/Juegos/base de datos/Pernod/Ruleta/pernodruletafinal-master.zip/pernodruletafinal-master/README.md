README - Modificaciones en la Ruleta

Mejoras Implementadas

Indicador de Premio

Se ha modificado la ruleta para incluir una flecha roja que señala el premio obtenido, mejorando la claridad visual del resultado.

Bloqueo de Botón durante el Giro

Ahora, una vez que la ruleta comienza a girar, el botón de activación queda deshabilitado hasta que finaliza el giro. Esto evita interacciones no deseadas y garantiza un funcionamiento correcto.

Modificación de Probabilidades

Se ha agregado la posibilidad de modificar las probabilidades de la ruleta, permitiendo forzar diferentes resultados según sea necesario.

Estas mejoras optimizan la experiencia de usuario y brindan mayor control sobre el funcionamiento de la ruleta.
